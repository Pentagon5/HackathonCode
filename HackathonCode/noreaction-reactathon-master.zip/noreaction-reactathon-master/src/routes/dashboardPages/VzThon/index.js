import React from 'react';
import VzThon from './vzThon';

export default {
  path: '/hackathons/VzThon',

  action() {
    return <VzThon />;
  },

};
