import React from 'react';
import Table from './Table';

export default {

  path: '/MyTeam',

  action() {
    return <Table />;
  },

};
