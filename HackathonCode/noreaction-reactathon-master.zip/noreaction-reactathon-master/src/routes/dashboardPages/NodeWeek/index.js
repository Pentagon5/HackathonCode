import React from 'react';
import NodeWeek from './nodeWeek';

export default {
  path: '/hackathons/NodeWeek',

  action() {
    return <NodeWeek />;
  },

};
