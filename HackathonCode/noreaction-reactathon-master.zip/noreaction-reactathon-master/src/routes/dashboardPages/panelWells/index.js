
import React from 'react';
import PanelWells from './PanelWells';

export default {

  path: '/panelwells',

  action() {
    return <PanelWells />;
  },

};
