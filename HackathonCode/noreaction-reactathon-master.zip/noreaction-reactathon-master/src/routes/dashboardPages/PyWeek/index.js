import React from 'react';
import PyWeek from './pyWeek';

export default {
  path: '/hackathons/PyWeek',

  action() {
    return <PyWeek />;
  },

};
