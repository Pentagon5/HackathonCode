
import React from 'react';
import Notification from './Notification';

export default {

  path: '/notification',

  action() {
    return <Notification />;
  },

};
