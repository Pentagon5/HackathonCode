import React from 'react';
import AngularDay from './AngularDay';

export default {
  path: '/hackathons/AngularDay',

  action() {
    return <AngularDay />;
  },

};
