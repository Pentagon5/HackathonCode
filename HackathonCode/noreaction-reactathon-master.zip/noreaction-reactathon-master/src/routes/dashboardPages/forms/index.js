
import React from 'react';
import Forms from './forms';

export default {

  path: '/ContactUS',

  action() {
    return <Forms />;
  },

};
