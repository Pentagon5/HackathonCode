
import React from 'react';
import MorrisjsCharts from './MorrisjsCharts';

export default {

  path: '/hackathons/Completed',

  action() {
    return <MorrisjsCharts />;
  },

};
