import React from 'react';
import Blank from './blank';

export default {
  path: '/blank',

  action() {
    return <Blank />;
  },

};
