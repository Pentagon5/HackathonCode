

import React from 'react';
// import App from '../../components/App';
import Login from './Login';

export default {

  path: '/',

  action() {
    return <Login />;
  },

};
