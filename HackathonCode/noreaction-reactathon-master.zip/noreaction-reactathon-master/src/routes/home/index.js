

import React from 'react';
import Home from './Home';
// import fetch from '../../core/fetch';

export default {

  path: '/',

  async action() {
    return <Home />;
    // const resp = await fetch('/graphql', {
    //   method: 'post',
    //   headers: {
    //     Accept: 'application/json',
    //     'Content-Type': 'application/json',
    //   },
    //   body: JSON.stringify({
    //     query: '{news{title,link,contentSnippet}}',
    //   }),
    //   credentials: 'include',
    // });
    // const { data } = await resp.json();
    // if (!data || !data.news) throw new Error('Failed to load the news feed.');
    // return <Home news={data.news} />;
  },

};
